#include<iostream>
#include<string>
#include<fstream>
using namespace std;

int main()
{
	char option;
	
	string name, rollno, emailid;
	cout << "\nEnter what operation you want\n";
	cout << " \na -> to add new student\n";
	cout << " \nb -> to read student record from file\n";
	cout << " \nc -> to Delete student record from file\n";
	cin >> option;

	if (option == 'a')
	{
		int counter = 0;
		string mytxt;
		ifstream fin;
		fin.open("record.txt");
		while (!fin.eof())
		{
			getline(fin, mytxt);
			if (mytxt[0] == counter);
			{
				counter++;
				for (int i = 1; i < 3; i++)
				{
					getline(fin, mytxt);
				}
			}
		}

		ofstream myfile;

		myfile.open("record.txt",ios_base::app);
		
		myfile <<"\n"<< counter-1 << " ";
		
		cout << "\nEnter name of a student : ";
		cin >> name;
		myfile <<"Name: "<<name<< "\n";
		cout << "\nEnter rollno : ";
		cin >> rollno;
		myfile <<"  Roll No: "<<rollno << "\n";
		cout << "\nEnter email id : ";
		cin >> emailid;
		myfile << "  Email: "<<emailid << "\n";
		

		cout << "\n**********Added successfully************\n";


		myfile.close();


	}
	else if (option == 'b')
	{
		ifstream fin;
		int counter;
		int x = 0;
		string mytxt;
		string key;
		cout << "\nEnter the key whose student record you want to read \n";
		cin >> key;
		fin.open("record.txt");
		if (!fin.is_open())
		{
			cout << "No file exist...";
		}
		else

		{
			while (!fin.eof() || x==0)
			{
				getline(fin, mytxt);
				if (mytxt[0] == key[0])
				{
					cout << "\nRead successfully\n";
					cout << "Information is below\n";
					x++;
						cout << mytxt;
						cout << endl;
						for (int i = 1; i < 3; i++)
						{
							getline(fin, mytxt);
							cout << mytxt;
							cout << endl;
						}
					
				}
			 }
			if (x == 0)
			{
				cout << "\nStudent not exist\n";
			}
			}

		fin.close();
	}
	else if (option == 'c')
	{
		string mytxt,key;
		cout << "\nEnter the key to whome you want to delete : ";
		cin >> key;
		ifstream fin;
		fin.open("record.txt");
		ofstream temp;
		temp.open("temp.txt");
		while (!fin.eof())
		{
			getline(fin, mytxt);
			
			if (mytxt[0] == key[0])
			{
				
				for (int i = 1; i < 3; i++)
				{
					getline(fin, mytxt);
					//cout << mytxt;
				}
				cout << "Deleted successfully";
			}
			else
			{
				temp << mytxt;
				temp << endl;
			}
			
		}
		fin.close();
		temp.close();
		remove("record.txt");
		rename("temp.txt", "record.txt");


	}
	return 0;
}
