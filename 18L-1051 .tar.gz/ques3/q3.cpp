#include<iostream>
#include<string>
#include<fstream>
using namespace std;



void reverseStr(string& str)
{
	int n = str.length();

	// Swap character starting from two 
	// corners 
	for (int i = 0; i < n / 2; i++)
		swap(str[i], str[n - i - 1]);
}

int main(int argc, char *arg[])
{
	ifstream fin;
	fin.open(arg[1]);

	if (!fin.is_open())
	{
		cout << "No file exist...";
	}

	else

	{
		string temp;
		int k = 0;
		int vowel_count = 0;
		int reverse_count ;
		ofstream newfile;
		newfile.open("newfile.txt", ios_base::app);

		int count = 0;
		int j = 0;
		int len = 0;
		string str;
		while (!fin.eof())
		{
			getline(fin, str);
			for (int i = 0; str[i] != '\0'; i++)
			{
				if (str[i + 1] == '\0')

				{
					temp += str[i];
					k++;

					k = 0;
					reverse_count = 0;
					for (int i = 0; temp[i] != '\0' && reverse_count == 0; i++)
					{
						if (temp[i] == 'a' || temp[i] == 'e' || temp[i] == 'i' || temp[i] == 'o' || temp[i] == 'u' || temp[i] == 'A' || temp[i] == 'E' || temp[i] == 'I' || temp[i] == 'O' || temp[i] == 'U')
						{
							reverseStr(temp);
							reverse_count++;
							newfile << temp;
							newfile << " ";

						}
					}
					temp = "";

				}
				
				else if (str[i] != ' ')
				{
					temp += str[i];
					k++;
				}
				else 
				{
					k = 0;
					reverse_count = 0;
					for (int i = 0; temp[i] != '\0' && reverse_count==0; i++)
					{
						if (temp[i] == 'a' || temp[i] == 'e' || temp[i] == 'i' || temp[i] == 'o' || temp[i] == 'u' || temp[i] == 'A' || temp[i] == 'E' || temp[i] == 'I' || temp[i] == 'O' || temp[i] == 'U')
						{
							reverseStr(temp);
							reverse_count++;
							newfile << temp;
							newfile << " ";
							
						}
					}
					temp = "";

				}

			}
			
		}

	
		cout << endl;

	}

	return 0;
}
