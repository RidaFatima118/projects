#include<iostream>
#include<string>
#include<fstream>
using namespace std;
int main(int argc, char *arg[])
{
	ifstream fin;
	fin.open(arg[1]);
	
	if (!fin.is_open())
	{
		cout << "No file exist...";
	}

	else

	{
		int count = 0;
		int len = 0;
		string str;
		while (!fin.eof())

		{
			fin >> str[len];
			len++;
		}
		str[len] = '\0';

		for (int i = 0; str[i] != '\0'; i++)
		{
			if (str[i] >= '0' && str[i] <= '9')
			{
				count++;
			}
		}
		cout << "\nTotal number of digits are:   " << count;
		cout << endl;

	}

	return 0;
}
